Student Number: 500706752
Username : mgng
Name: Alex (Matthew) Ng
Course: cps630
Lab: 4

Note: Lab may need to be run hosted on a web server as the initial model for the list in JSON is requested though a http request (which may not work when running my lab locally under file:///dir/index.html) if this is the case the lab is also hosted on https://cynicalbird.github.io/cps630/labs/lab4/index.html

Home page:
	Functionality:
		+List model is initialized through plain js http request of a json text response
		+User can add tasks to the list
		+User can remove tasks from the list
		+User can complete tasks from the list
		+Task view is retrieved through ng-include
		-Did not have time for filter