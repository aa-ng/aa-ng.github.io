
//var todo = angular.module('todo', []);
//todo.controller('todoController', function($scope) {
<!--
function todoController ($scope)
{
	$scope.list = requestTodo().todo;
	log('todoController',$scope.list);
}
-->
//});

function addTodo()
{

}